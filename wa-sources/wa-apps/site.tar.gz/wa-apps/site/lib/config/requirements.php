<?php
return array(
    'app.installer'=>array(
        'version'=>'>=1.5.0',
        'strict'=>true,
    ),
);
//EOF