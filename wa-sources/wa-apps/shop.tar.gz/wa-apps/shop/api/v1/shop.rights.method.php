<?php

class shopRightsMethod extends waAPIRightsMethod
{
    protected $app = 'shop';
}