<?php 

class webasystOAuthController extends waOAuthController
{
}