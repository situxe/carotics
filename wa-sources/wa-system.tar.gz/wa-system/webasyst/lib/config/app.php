<?php

return array(
    'name' => 'Webasyst',
    'prefix' => 'webasyst',
    'version' => '1.5.10',
    'critical'=>'1.5.10',
    'vendor' => 'webasyst',
);
