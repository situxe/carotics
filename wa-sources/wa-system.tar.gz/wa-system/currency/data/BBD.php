<?php

return array(
    'code' => 'BBD',
    'sign' => 'Bds$',
    'sign_position' => 0,
    'sign_delim' => '',
    'title' => 'Barbadian dollar',
    'name' => array(
        array('dollar', 'dollars'),
    ),
    'frac_name' => array(
        array('cent', 'cents'),
    )
);