<?php

return array(
    'code' => 'HRK',
    'sign' => 'kn',
    'sign_position' => null,
    'sign_delim' => null,
    'title' => 'Croatian kuna',
    'name' => array(
        'kuna',
    ),
    'frac_name' => array(
        'lipa',
    )
);