<?php

return array(
    'code' => 'KPW',
    'sign' => '₩',
    'sign_position' => 0,
    'sign_delim' => '',
    'title' => 'North Korean won',
    'name' => array(
        'won',
    ),
    'frac_name' => array(
        'chon',
    )
);