<?php

return array(
    'code' => 'UZS',
    'sign' => 'som',
    'sign_position' => null,
    'sign_delim' => null,
    'title' => 'Uzbekistani som',
    'name' => array(
        'som',
    ),
    'frac_name' => array(
        'tiyin',
    )
);