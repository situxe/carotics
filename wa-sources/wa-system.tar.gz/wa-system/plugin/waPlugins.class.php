<?php 

class waPlugins
{

}